import { useEffect, useState } from 'react';
import { storage } from '../services/storage';
import { useAuth } from '../contexts/AuthContext';
import { Plus, BookOpen, Edit, Trash2, Clock } from 'lucide-react';
import CourseForm from '../components/CourseForm';

const CourseList = () => {
  const { isAdmin } = useAuth();
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState(undefined);

  const fetchCourses = () => {
    const data = storage.getCourses();
    setCourses(data.sort((a, b) => a.title.localeCompare(b.title)));
    setLoading(false);
  };

  useEffect(() => {
    fetchCourses();
  }, []);

  const handleDelete = (id) => {
    if (!window.confirm('Tem certeza que deseja excluir este curso? Isso não removerá os certificados já emitidos.')) return;
    storage.deleteCourse(id);
    fetchCourses();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-1">Cursos</h1>
          <p className="text-slate-500">Gerencie o catálogo de cursos oferecidos pela igreja.</p>
        </div>
        {isAdmin && (
          <button
            onClick={() => {
              setEditingCourse(undefined);
              setIsFormOpen(true);
            }}
            className="flex items-center justify-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold py-3 px-6 rounded-2xl transition-all shadow-lg shadow-violet-100"
          >
            <Plus size={20} />
            Novo Curso
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.length > 0 ? (
          courses.map((course) => (
            <div key={course.id} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group">
              <div className="flex items-center justify-between mb-6">
                <div className="p-3 bg-violet-50 text-violet-600 rounded-2xl">
                  <BookOpen size={24} />
                </div>
                {isAdmin && (
                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        setEditingCourse(course);
                        setIsFormOpen(true);
                      }}
                      className="p-2 text-slate-400 hover:text-violet-600 hover:bg-violet-50 rounded-xl transition-all"
                    >
                      <Edit size={18} />
                    </button>
                    <button 
                      onClick={() => handleDelete(course.id)}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                )}
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-3">{course.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed mb-6 line-clamp-3">
                {course.description || 'Nenhuma descrição fornecida para este curso.'}
              </p>

              <div className="pt-6 border-t border-slate-50 flex items-center gap-4 text-slate-400 text-sm">
                <div className="flex items-center gap-1.5">
                  <Clock size={16} />
                  <span>{course.duration || 'Duração N/A'}</span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full py-12 flex flex-col items-center justify-center text-slate-400 bg-white rounded-3xl border border-dashed border-slate-200">
            <BookOpen size={48} className="mb-4 opacity-20" />
            <p className="text-lg font-medium">Nenhum curso cadastrado</p>
          </div>
        )}
      </div>

      {isFormOpen && (
        <CourseForm 
          course={editingCourse} 
          onClose={() => {
            setIsFormOpen(false);
            fetchCourses();
          }} 
        />
      )}
    </div>
  );
};

export default CourseList;
