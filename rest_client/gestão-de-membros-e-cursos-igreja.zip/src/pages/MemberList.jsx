import { useEffect, useState } from 'react';
import { storage } from '../services/storage';
import { useAuth } from '../contexts/AuthContext';
import { Search, EyeOff, UserPlus, Users, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import MemberForm from '../components/MemberForm';

const MemberList = () => {
  const { isAdmin } = useAuth();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [filterStatus, setFilterStatus] = useState('all');

  const fetchMembers = () => {
    const membersData = storage.getMembers();
    
    // If not admin, filter out hidden records
    if (!isAdmin) {
      setMembers(membersData.filter(m => !m.isHidden));
    } else {
      setMembers(membersData);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMembers();
  }, [isAdmin]);

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         member.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || member.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 mb-1">Frequentadores</h1>
          <p className="text-slate-500">Gerencie o cadastro de todos os frequentadores da igreja.</p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setIsFormOpen(true)}
            className="flex items-center justify-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold py-3 px-6 rounded-2xl transition-all shadow-lg shadow-violet-100"
          >
            <UserPlus size={20} />
            Novo Frequentador
          </button>
        )}
      </div>

      {/* Search and Filter Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Buscar por nome ou e-mail..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
          />
        </div>
        <div className="flex gap-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 text-slate-600 font-medium"
          >
            <option value="all">Todos os Status</option>
            <option value="active">Ativos</option>
            <option value="inactive">Inativos</option>
          </select>
        </div>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.length > 0 ? (
          filteredMembers.map((member) => (
            <Link
              key={member.id}
              to={`/members/${member.id}`}
              className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all group relative overflow-hidden"
            >
              {member.isHidden && (
                <div className="absolute top-4 right-4 text-slate-400" title="Registro Oculto">
                  <EyeOff size={18} />
                </div>
              )}
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-violet-50 text-violet-700 flex items-center justify-center text-xl font-bold">
                  {member.name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-bold text-slate-900 truncate group-hover:text-violet-600 transition-colors">
                    {member.name}
                  </h3>
                  <p className="text-sm text-slate-500 truncate">{member.email || 'Sem e-mail'}</p>
                </div>
              </div>
              
              <div className="space-y-3 mb-6">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Status</span>
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    member.status === 'active' ? "bg-violet-100 text-violet-700" : "bg-slate-100 text-slate-600"
                  )}>
                    {member.status === 'active' ? 'Ativo' : 'Inativo'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Telefone</span>
                  <span className="text-slate-700 font-medium">{member.phone || '—'}</span>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-50 flex items-center justify-between text-violet-600 font-semibold text-sm">
                <span>Ver Detalhes</span>
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full py-12 flex flex-col items-center justify-center text-slate-400 bg-white rounded-3xl border border-dashed border-slate-200">
            <Users size={48} className="mb-4 opacity-20" />
            <p className="text-lg font-medium">Nenhum frequentador encontrado</p>
            <p className="text-sm">Tente ajustar sua busca ou filtros.</p>
          </div>
        )}
      </div>

      {/* Member Form Modal */}
      {isFormOpen && (
        <MemberForm onClose={() => {
          setIsFormOpen(false);
          fetchMembers();
        }} />
      )}
    </div>
  );
};

// Helper for class names
function cn(...inputs) {
  return inputs.filter(Boolean).join(' ');
}

export default MemberList;
