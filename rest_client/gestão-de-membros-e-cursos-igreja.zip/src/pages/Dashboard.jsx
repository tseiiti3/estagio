import { useEffect, useState } from 'react';
import { storage } from '../services/storage';
import { Users, BookOpen, GraduationCap, Award, ArrowRight, Church } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const [stats, setStats] = useState({
    members: 0,
    courses: 0,
    certificates: 0,
    activeMembers: 0
  });
  const [recentMembers, setRecentMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = () => {
      const members = storage.getMembers();
      const courses = storage.getCourses();
      const certificates = storage.getMemberCourses();
      
      setStats({
        members: members.length,
        courses: courses.length,
        certificates: certificates.length,
        activeMembers: members.filter(m => m.status === 'active').length
      });

      // Get recent members (last 5)
      setRecentMembers(members.slice(-5).reverse());
      setLoading(false);
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  const statCards = [
    { label: 'Total de Frequentadores', value: stats.members, icon: Users, color: 'bg-blue-50 text-blue-600' },
    { label: 'Membros Ativos', value: stats.activeMembers, icon: GraduationCap, color: 'bg-violet-50 text-violet-600' },
    { label: 'Cursos Disponíveis', value: stats.courses, icon: BookOpen, color: 'bg-amber-50 text-amber-600' },
    { label: 'Certificados Emitidos', value: stats.certificates, icon: Award, color: 'bg-purple-50 text-purple-600' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Painel de Controle</h1>
        <p className="text-slate-500">Visão geral do sistema de gestão da igreja (Local Storage).</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-3 rounded-2xl", stat.color)}>
                <stat.icon size={24} />
              </div>
            </div>
            <p className="text-sm font-medium text-slate-500 mb-1">{stat.label}</p>
            <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Members */}
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex items-center justify-between">
            <h2 className="text-xl font-bold text-slate-900">Novos Frequentadores</h2>
            <Link to="/members" className="text-violet-600 hover:text-violet-700 text-sm font-semibold flex items-center gap-1">
              Ver todos <ArrowRight size={16} />
            </Link>
          </div>
          <div className="divide-y divide-slate-50">
            {recentMembers.length > 0 ? (
              recentMembers.map((member) => (
                <Link 
                  key={member.id} 
                  to={`/members/${member.id}`}
                  className="flex items-center gap-4 p-4 hover:bg-slate-50 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 font-bold">
                    {member.name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{member.name}</p>
                    <p className="text-xs text-slate-500 truncate">{member.email || 'Sem e-mail'}</p>
                  </div>
                  <span className={cn(
                    "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    member.status === 'active' ? "bg-violet-100 text-violet-700" : "bg-slate-100 text-slate-600"
                  )}>
                    {member.status === 'active' ? 'Ativo' : 'Inativo'}
                  </span>
                </Link>
              ))
            ) : (
              <div className="p-8 text-center text-slate-400">Nenhum registro encontrado.</div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-8 flex flex-col justify-center items-center text-center space-y-6">
          <div className="w-16 h-16 bg-violet-50 text-violet-600 rounded-2xl flex items-center justify-center">
            <Church size={32} />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Ações Rápidas</h2>
            <p className="text-slate-500 max-w-xs mx-auto">
              Acesse as principais funcionalidades do sistema com facilidade.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 w-full">
            <Link 
              to="/members" 
              className="flex flex-col items-center gap-2 p-4 bg-slate-50 hover:bg-violet-50 hover:text-violet-700 rounded-2xl transition-all group"
            >
              <Users size={24} className="text-slate-400 group-hover:text-violet-600" />
              <span className="text-sm font-semibold">Membros</span>
            </Link>
            <Link 
              to="/courses" 
              className="flex flex-col items-center gap-2 p-4 bg-slate-50 hover:bg-violet-50 hover:text-violet-700 rounded-2xl transition-all group"
            >
              <BookOpen size={24} className="text-slate-400 group-hover:text-violet-600" />
              <span className="text-sm font-semibold">Cursos</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper for class names
function cn(...inputs) {
  return inputs.filter(Boolean).join(' ');
}

export default Dashboard;
