import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { storage } from '../services/storage';
import { useAuth } from '../contexts/AuthContext';
import { 
  ArrowLeft, 
  Edit, 
  Trash2, 
  Phone, 
  Calendar, 
  MapPin, 
  Award, 
  Plus, 
  FileText, 
  GraduationCap
} from 'lucide-react';
import MemberForm from '../components/MemberForm';
import MemberCourseForm from '../components/MemberCourseForm';

const MemberDetail = () => {
  const { id } = useParams();
  const { isAdmin } = useAuth();
  const navigate = useNavigate();
  
  const [member, setMember] = useState(null);
  const [memberCourses, setMemberCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isAddCourseOpen, setIsAddCourseOpen] = useState(false);

  const fetchData = () => {
    if (!id) return;
    const m = storage.getMembers().find(m => m.id === id);
    if (m) {
      setMember(m);
      const mc = storage.getMemberCourses().filter(mc => mc.memberId === id);
      const courses = storage.getCourses();
      const coursesMap = new Map(courses.map(c => [c.id, c]));
      
      setMemberCourses(mc.map(item => ({
        ...item,
        course: coursesMap.get(item.courseId)
      })));
    } else {
      navigate('/members');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [id, navigate]);

  const handleDelete = () => {
    if (!member || !window.confirm('Tem certeza que deseja excluir este frequentador?')) return;
    storage.deleteMember(member.id);
    navigate('/members');
  };

  const handleDeleteCourse = (mcId) => {
    if (!window.confirm('Remover este curso do registro do membro?')) return;
    storage.deleteMemberCourse(mcId);
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  if (!member) return null;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button 
          onClick={() => navigate('/members')}
          className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-semibold transition-colors w-fit"
        >
          <ArrowLeft size={20} />
          Voltar para Lista
        </button>
        {isAdmin && (
          <div className="flex gap-3">
            <button
              onClick={() => setIsEditOpen(true)}
              className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 font-semibold py-2 px-4 rounded-xl hover:bg-slate-50 transition-colors"
            >
              <Edit size={18} />
              Editar
            </button>
            <button
              onClick={handleDelete}
              className="flex items-center gap-2 bg-red-50 text-red-600 font-semibold py-2 px-4 rounded-xl hover:bg-red-100 transition-colors"
            >
              <Trash2 size={18} />
              Excluir
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Info */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center">
            <div className="w-24 h-24 rounded-3xl bg-violet-50 text-violet-700 flex items-center justify-center text-3xl font-bold mx-auto mb-6">
              {member.name[0]}
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-1">{member.name}</h1>
            <p className="text-slate-500 mb-6">{member.email || 'Sem e-mail'}</p>
            <span className={cn(
              "px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider",
              member.status === 'active' ? "bg-violet-100 text-violet-700" : "bg-slate-100 text-slate-600"
            )}>
              {member.status === 'active' ? 'Ativo' : 'Inativo'}
            </span>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <h2 className="text-lg font-bold text-slate-900 border-b border-slate-50 pb-4">Informações de Contato</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg text-slate-400">
                  <Phone size={18} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Telefone</p>
                  <p className="text-slate-700 font-medium">{member.phone || 'Não informado'}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg text-slate-400">
                  <Calendar size={18} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Nascimento</p>
                  <p className="text-slate-700 font-medium">{member.birthDate || 'Não informado'}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 bg-slate-50 rounded-lg text-slate-400">
                  <MapPin size={18} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-400 uppercase">Endereço</p>
                  <p className="text-slate-700 font-medium leading-relaxed">{member.address || 'Não informado'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Courses & Certificates */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="p-8 border-b border-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-violet-50 text-violet-600 rounded-xl">
                  <GraduationCap size={24} />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Cursos e Certificados</h2>
              </div>
              {isAdmin && (
                <button
                  onClick={() => setIsAddCourseOpen(true)}
                  className="flex items-center gap-2 text-violet-600 hover:text-violet-700 font-bold text-sm"
                >
                  <Plus size={18} />
                  Adicionar Curso
                </button>
              )}
            </div>

            <div className="p-8">
              {memberCourses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {memberCourses.map((mc) => (
                    <div key={mc.id} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 group relative">
                      {isAdmin && (
                        <button 
                          onClick={() => handleDeleteCourse(mc.id)}
                          className="absolute top-4 right-4 p-2 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                      <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-white rounded-lg text-violet-600 shadow-sm">
                          <Award size={20} />
                        </div>
                        <h3 className="font-bold text-slate-900 truncate pr-6">{mc.course?.title || 'Curso Removido'}</h3>
                      </div>
                      
                      <div className="space-y-2 text-sm mb-6">
                        <p className="text-slate-500 flex items-center justify-between">
                          <span>Conclusão:</span>
                          <span className="text-slate-700 font-semibold">{mc.completionDate || 'N/A'}</span>
                        </p>
                      </div>

                      <div className="flex gap-2">
                        {mc.certificateUrl && (
                          <a 
                            href={mc.certificateUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-600 py-2 rounded-xl text-xs font-bold hover:bg-slate-100 transition-colors"
                          >
                            <FileText size={14} />
                            Certificado
                          </a>
                        )}
                        {mc.diplomaUrl && (
                          <a 
                            href={mc.diplomaUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex-1 flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-600 py-2 rounded-xl text-xs font-bold hover:bg-slate-100 transition-colors"
                          >
                            <Award size={14} />
                            Diploma
                          </a>
                        )}
                        {!mc.certificateUrl && !mc.diplomaUrl && (
                          <p className="text-xs text-slate-400 italic">Nenhum documento anexado</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-slate-50 text-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award size={32} />
                  </div>
                  <p className="text-slate-500 font-medium">Nenhum curso registrado para este membro.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {isEditOpen && (
        <MemberForm member={member} onClose={() => {
          setIsEditOpen(false);
          fetchData();
        }} />
      )}
      {isAddCourseOpen && (
        <MemberCourseForm memberId={member.id} onClose={() => {
          setIsAddCourseOpen(false);
          fetchData();
        }} />
      )}
    </div>
  );
};

// Helper for class names
function cn(...inputs) {
  return inputs.filter(Boolean).join(' ');
}

export default MemberDetail;
