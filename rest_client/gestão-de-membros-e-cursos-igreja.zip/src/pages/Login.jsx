import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import { Church, ShieldCheck, User } from 'lucide-react';

const Login = () => {
  const { user, login, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-600"></div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" />;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-xl shadow-slate-200/50 p-8 md:p-12 border border-slate-100">
        <div className="flex flex-col items-center mb-10">
          <div className="w-20 h-20 bg-violet-50 text-violet-600 rounded-2xl flex items-center justify-center mb-6 shadow-inner">
            <Church size={48} />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Bem-vindo</h1>
          <p className="text-slate-500 text-center">
            Sistema de Gestão de Membros e Cursos (Versão Local)
          </p>
        </div>

        <div className="space-y-4">
          <button
            onClick={() => login('admin')}
            className="w-full flex items-center justify-center gap-3 bg-violet-600 hover:bg-violet-700 text-white font-semibold py-4 px-6 rounded-2xl transition-all duration-200 shadow-lg shadow-violet-200 active:scale-[0.98]"
          >
            <ShieldCheck size={20} />
            Entrar como Administrador
          </button>
          
          <button
            onClick={() => login('member')}
            className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold py-4 px-6 rounded-2xl transition-all duration-200 active:scale-[0.98]"
          >
            <User size={20} />
            Entrar como Visitante
          </button>
        </div>

        <div className="mt-10 pt-8 border-t border-slate-100 text-center">
          <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">
            Modo de Demonstração Local
          </p>
        </div>
      </div>
      
      <p className="mt-8 text-slate-400 text-sm">
        © 2026 Igreja Gestão • Todos os dados são salvos localmente no seu navegador.
      </p>
    </div>
  );
};

export default Login;
