const STORAGE_KEYS = {
  MEMBERS: 'church_members',
  COURSES: 'church_courses',
  MEMBER_COURSES: 'church_member_courses',
  USER: 'church_user_profile'
};

const get = (key, defaultValue) => {
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : defaultValue;
};

const set = (key, value) => {
  localStorage.setItem(key, JSON.stringify(value));
};

export const storage = {
  getMembers: () => get(STORAGE_KEYS.MEMBERS, []),
  addMember: (member) => {
    const members = storage.getMembers();
    const newMember = {
      ...member,
      id: Math.random().toString(36).substr(2, 9),
      createdAt: new Date().toISOString()
    };
    members.push(newMember);
    set(STORAGE_KEYS.MEMBERS, members);
  },
  updateMember: (id, member) => {
    const members = storage.getMembers();
    const index = members.findIndex(m => m.id === id);
    if (index !== -1) {
      members[index] = { ...members[index], ...member };
      set(STORAGE_KEYS.MEMBERS, members);
    }
  },
  deleteMember: (id) => {
    const members = storage.getMembers().filter(m => m.id !== id);
    set(STORAGE_KEYS.MEMBERS, members);
    // Also cleanup member courses
    const mc = storage.getMemberCourses().filter(m => m.memberId !== id);
    set(STORAGE_KEYS.MEMBER_COURSES, mc);
  },

  getCourses: () => get(STORAGE_KEYS.COURSES, []),
  addCourse: (course) => {
    const courses = storage.getCourses();
    const newCourse = {
      ...course,
      id: Math.random().toString(36).substr(2, 9)
    };
    courses.push(newCourse);
    set(STORAGE_KEYS.COURSES, courses);
  },
  updateCourse: (id, course) => {
    const courses = storage.getCourses();
    const index = courses.findIndex(c => c.id === id);
    if (index !== -1) {
      courses[index] = { ...courses[index], ...course };
      set(STORAGE_KEYS.COURSES, courses);
    }
  },
  deleteCourse: (id) => {
    const courses = storage.getCourses().filter(c => c.id !== id);
    set(STORAGE_KEYS.COURSES, courses);
  },

  getMemberCourses: () => get(STORAGE_KEYS.MEMBER_COURSES, []),
  addMemberCourse: (mc) => {
    const list = storage.getMemberCourses();
    const newMc = {
      ...mc,
      id: Math.random().toString(36).substr(2, 9)
    };
    list.push(newMc);
    set(STORAGE_KEYS.MEMBER_COURSES, list);
  },
  deleteMemberCourse: (id) => {
    const list = storage.getMemberCourses().filter(m => m.id !== id);
    set(STORAGE_KEYS.MEMBER_COURSES, list);
  }
};
