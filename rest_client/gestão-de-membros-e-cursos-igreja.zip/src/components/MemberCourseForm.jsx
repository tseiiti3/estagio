import { useState, useEffect } from 'react';
import { storage } from '../services/storage';
import { X, Save, Award, Calendar, FileText } from 'lucide-react';

const MemberCourseForm = ({ memberId, onClose }) => {
  const [courses, setCourses] = useState([]);
  const [formData, setFormData] = useState({
    memberId: memberId,
    courseId: '',
    completionDate: new Date().toISOString().split('T')[0],
    certificateUrl: '',
    diplomaUrl: ''
  });

  useEffect(() => {
    setCourses(storage.getCourses());
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.courseId) {
      alert('Por favor, selecione um curso.');
      return;
    }
    storage.addMemberCourse(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900">Registrar Conclusão de Curso</h2>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-xl transition-colors text-slate-400 hover:text-slate-900">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-6">
            {/* Course Selection */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Selecionar Curso</label>
              <div className="relative">
                <Award className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <select
                  required
                  value={formData.courseId}
                  onChange={(e) => setFormData({ ...formData, courseId: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all appearance-none"
                >
                  <option value="">Selecione um curso...</option>
                  {courses.map(course => (
                    <option key={course.id} value={course.id}>{course.title}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Completion Date */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Data de Conclusão</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  required
                  type="date"
                  value={formData.completionDate}
                  onChange={(e) => setFormData({ ...formData, completionDate: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                />
              </div>
            </div>

            {/* Certificate URL */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Link do Certificado (Opcional)</label>
              <div className="relative">
                <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  type="url"
                  value={formData.certificateUrl}
                  onChange={(e) => setFormData({ ...formData, certificateUrl: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                  placeholder="https://exemplo.com/certificado.pdf"
                />
              </div>
            </div>

            {/* Diploma URL */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Link do Diploma (Opcional)</label>
              <div className="relative">
                <Award className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  type="url"
                  value={formData.diplomaUrl}
                  onChange={(e) => setFormData({ ...formData, diplomaUrl: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                  placeholder="https://exemplo.com/diploma.pdf"
                />
              </div>
            </div>
          </div>

          <div className="pt-6 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-4 px-6 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-2xl transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-4 px-6 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-violet-100 flex items-center justify-center gap-2"
            >
              <Save size={20} />
              Salvar Registro
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MemberCourseForm;
