import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  LogOut, 
  Menu, 
  X, 
  Church,
  ChevronRight,
  User,
  ShieldCheck
} from 'lucide-react';

const Layout = ({ children }) => {
  const { user, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const menuItems = [
    { path: '/', label: 'Painel', icon: LayoutDashboard },
    { path: '/members', label: 'Frequentadores', icon: Users },
    { path: '/courses', label: 'Cursos', icon: BookOpen },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row font-sans text-slate-900">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-slate-100 px-4 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-violet-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-violet-100">
            <Church size={24} />
          </div>
          <span className="font-bold text-xl tracking-tight">Igreja Gestão</span>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 text-slate-500 hover:bg-slate-50 rounded-lg transition-colors"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-0 z-40 md:relative md:z-auto bg-white border-r border-slate-100 w-72 flex-shrink-0 transition-transform duration-300 ease-in-out md:translate-x-0",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full flex flex-col p-6">
          {/* Logo */}
          <div className="hidden md:flex items-center gap-3 mb-12 px-2">
            <div className="w-12 h-12 bg-violet-600 text-white rounded-2xl flex items-center justify-center shadow-xl shadow-violet-100">
              <Church size={28} />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-xl tracking-tight leading-none">Igreja Gestão</span>
              <span className="text-[10px] font-bold text-violet-600 uppercase tracking-widest mt-1">Administração</span>
            </div>
          </div>

          {/* User Profile Summary */}
          <div className="bg-slate-50 rounded-3xl p-5 mb-8 border border-slate-100/50">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-violet-600 shadow-sm border border-slate-100">
                {isAdmin ? <ShieldCheck size={24} /> : <User size={24} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm truncate">{user?.name || 'Usuário'}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  {isAdmin ? 'Administrador' : 'Visitante'}
                </p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-white hover:bg-red-50 text-slate-500 hover:text-red-600 rounded-xl text-xs font-bold transition-all border border-slate-100"
            >
              <LogOut size={14} />
              Sair do Sistema
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-2">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-4 mb-4">Menu Principal</p>
            {menuItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "flex items-center justify-between px-4 py-3.5 rounded-2xl transition-all group",
                    isActive 
                      ? "bg-violet-50 text-violet-700 shadow-sm" 
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <item.icon size={20} className={cn(isActive ? "text-violet-600" : "text-slate-400 group-hover:text-slate-600")} />
                    <span className="font-semibold text-sm">{item.label}</span>
                  </div>
                  {isActive && <ChevronRight size={16} className="text-violet-400" />}
                </Link>
              );
            })}
          </nav>

          {/* Footer Info */}
          <div className="mt-auto pt-6 border-t border-slate-50 text-center">
            <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">Versão 1.0.0 (Local)</p>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-10 lg:p-12 max-w-7xl mx-auto w-full">
        {children}
      </main>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

// Helper for class names
function cn(...inputs) {
  return inputs.filter(Boolean).join(' ');
}

export default Layout;
