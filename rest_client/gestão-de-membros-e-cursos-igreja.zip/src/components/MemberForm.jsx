import { useState } from 'react';
import { storage } from '../services/storage';
import { X, Save, User, Mail, Phone, Calendar, MapPin, Eye, EyeOff } from 'lucide-react';

const MemberForm = ({ member, onClose }) => {
  const [formData, setFormData] = useState({
    name: member?.name || '',
    email: member?.email || '',
    phone: member?.phone || '',
    birthDate: member?.birthDate || '',
    address: member?.address || '',
    status: member?.status || 'active',
    isHidden: member?.isHidden || false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (member) {
      storage.updateMember(member.id, formData);
    } else {
      storage.addMember(formData);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900">
            {member ? 'Editar Frequentador' : 'Novo Frequentador'}
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-xl transition-colors text-slate-400 hover:text-slate-900">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Name */}
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Nome Completo</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                  placeholder="Ex: João Silva"
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                  placeholder="joao@exemplo.com"
                />
              </div>
            </div>

            {/* Phone */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Telefone</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                  placeholder="(00) 00000-0000"
                />
              </div>
            </div>

            {/* Birth Date */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Data de Nascimento</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
                />
              </div>
            </div>

            {/* Status */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Status</label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                className="w-full px-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all"
              >
                <option value="active">Ativo</option>
                <option value="inactive">Inativo</option>
              </select>
            </div>

            {/* Address */}
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Endereço</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-4 text-slate-300" size={18} />
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-violet-500 transition-all min-h-[100px]"
                  placeholder="Rua, Número, Bairro, Cidade..."
                />
              </div>
            </div>

            {/* Hidden Option */}
            <div className="md:col-span-2 flex items-center gap-3 p-4 bg-slate-50 rounded-2xl">
              <button
                type="button"
                onClick={() => setFormData({ ...formData, isHidden: !formData.isHidden })}
                className={cn(
                  "p-2 rounded-xl transition-all",
                  formData.isHidden ? "bg-amber-100 text-amber-600" : "bg-white text-slate-300"
                )}
              >
                {formData.isHidden ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
              <div>
                <p className="text-sm font-bold text-slate-900">Ocultar registro para visitantes</p>
                <p className="text-xs text-slate-500">Apenas administradores poderão ver este frequentador.</p>
              </div>
            </div>
          </div>

          <div className="pt-6 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-4 px-6 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-2xl transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-4 px-6 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-violet-100 flex items-center justify-center gap-2"
            >
              <Save size={20} />
              {member ? 'Salvar Alterações' : 'Cadastrar Frequentador'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// Helper for class names
function cn(...inputs) {
  return inputs.filter(Boolean).join(' ');
}

export default MemberForm;
