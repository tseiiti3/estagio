```markdown
# Design System Strategy: The Serene Steward

## 1. Overview & Creative North Star
The core of this design system is a concept we call **"The Serene Steward."** In the context of church management, the software must act as a quiet, capable presence—removing administrative friction so the focus remains on community and ministry. 

We are moving away from the "clunky database" aesthetic. Instead, we are adopting a **High-End Editorial** approach. This means prioritizing massive amounts of negative space, intentional asymmetry in dashboard layouts, and a sophisticated layering of warm neutrals. By using high-contrast typography scales (the interplay between the structural *Manrope* and the functional *Inter*), we create a digital environment that feels as welcoming as a physical sanctuary.

## 2. Colors & Surface Philosophy
The palette utilizes "Trustful Blues" to anchor the brand in stability, while "Warm Grays" and off-whites (`#fffcf7`) prevent the interface from feeling clinical.

### The "No-Line" Rule
To achieve a premium feel, **1px solid borders are prohibited for sectioning.** Boundaries must be defined solely through background color shifts or tonal transitions. For example:
- A side navigation bar should use `surface-container-low`.
- The main content area should use `surface`.
- Inner modules or "cards" should use `surface-container-lowest`.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine, heavy-weight paper.
- **Level 0 (Base):** `surface` (#fffcf7) - The canvas.
- **Level 1 (Sections):** `surface-container-low` (#fcf9f3) - Soft grouping.
- **Level 2 (Active Components):** `surface-container-lowest` (#ffffff) - High-importance cards or inputs.
- **Level 3 (Pop-overs):** `surface-container-highest` (#eae8e0) - Temporary overlays.

### The "Glass & Gradient" Rule
To add "soul" to the data, use Glassmorphism for floating action buttons or headers. 
- Use a background of `surface` at 80% opacity with a `backdrop-blur` of 12px.
- **Signature Gradients:** For primary CTAs, use a subtle linear gradient from `primary` (#446596) to `primary_dim` (#375989) at a 135-degree angle. This prevents the "flat" look of generic SaaS tools.

## 3. Typography
Our typography is a dialogue between two sans-serifs: **Manrope** (The Voice) and **Inter** (The Information).

- **Manrope (Display & Headline):** Used for big, welcoming moments. Use `display-lg` for welcome screens and `headline-md` for page titles. The wide apertures of Manrope feel open and inviting.
- **Inter (Title, Body, Label):** Used for data-heavy views. Inter’s tall x-height ensures that member directories and financial reports remain legible at smaller sizes (`body-sm` or `label-md`).
- **Editorial Contrast:** Always pair a `display-sm` headline with a `body-md` description. The jump in scale creates a clear visual hierarchy that guides the eye without needing heavy dividers.

## 4. Elevation & Depth
We eschew "Standard Material" shadows in favor of **Tonal Layering.**

- **The Layering Principle:** Place a `surface-container-lowest` card onto a `surface-container-low` background. This creates a "soft lift" that feels architectural rather than digital.
- **Ambient Shadows:** If a floating element (like a modal) requires a shadow, use a diffusion of 40px with an opacity of 6% using the `on_surface` color. It should look like a soft glow of depth, not a harsh drop-shadow.
- **The "Ghost Border" Fallback:** If accessibility requires a stroke (e.g., high-contrast mode), use the `outline_variant` token at **15% opacity**. Never use 100% opaque borders.

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_dim`), `on_primary` text, `xl` (1.5rem) rounded corners.
- **Secondary:** `secondary_container` fill with `on_secondary_container` text.
- **Tertiary:** No fill. Use `primary` text with a `surface-container-high` background on hover.

### Cards & Lists
- **The "No Divider" Mandate:** Forbid the use of horizontal lines between list items. Use vertical spacing (token `4` or `1rem`) and subtle background shifts on hover (`surface-container-high`) to define rows.
- **Member Cards:** Use `surface-container-lowest` with an `xl` corner radius. Ensure padding is generous (token `6` or 1.5rem).

### Input Fields
- **Styling:** Soft `surface-container-highest` backgrounds instead of white boxes with borders. 
- **Focus State:** A 2px "Ghost Border" using `primary_fixed` at 50% opacity.

### Navigation (Desktop & Mobile)
- **Desktop Sidebar:** Use `surface-container-low` with a 24px right-side margin from the content.
- **Mobile Bottom Bar:** Glassmorphic (`surface` @ 80% + blur) with `secondary` icons.

### Specialized Church Components
- **Giving Tracker:** Use a `tertiary_container` background for progress bars to differentiate financial data from general administration.
- **Ministry Tags:** Use `secondary_fixed_dim` chips with `on_secondary_fixed` text for a muted, professional look.

## 6. Do's and Don'ts

### Do:
- **Use "Asymmetric Breathing Room":** Push content 64px (token `16`) from the top but only 32px (token `8`) from the sides to create an editorial feel.
- **Embrace Roundedness:** Use the `xl` (1.5rem) corner radius for large containers to maintain the "welcoming" brand promise.
- **Layer Color:** Place `primary_container` elements behind `on_primary_container` text for high-importance alerts.

### Don't:
- **Don't use pure black:** Use `on_surface` (#383833) for all text to keep the interface warm.
- **Don't use 1px lines:** If you feel the need for a line, try using an 8px gap of background color instead.
- **Don't crowd the data:** Church management involves people's lives; give the data "room to breathe" to reduce administrative anxiety.

---
**Director's Final Note:**
This system is not a grid of boxes; it is a composition of surfaces. When in doubt, add more white space and remove a border. Let the typography and the subtle shifts in warm gray do the heavy lifting.```